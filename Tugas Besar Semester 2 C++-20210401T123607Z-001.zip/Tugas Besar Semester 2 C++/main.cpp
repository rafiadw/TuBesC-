#include <iostream>
#include<string>
#include "rafi.h"
#include<iostream>
#include<stdlib.h>

using namespace std;

int main()
{
    list_animal a;
    createListAnimal(a);
    list_zoo z;
    createListZoo(z);
    list_relation r;
    createListRelation(r);
    adr_animal g;
    adr_zoo h;
    int choice;
    bool lanjut=true;
    while(lanjut){
        system("cls");
        cout<<"Data Kebun Binatang "<<endl<<endl;
        viewZoo(z);
        viewAnimal(a);
        cout<<endl;
        cout<<"Menu : "<<endl;
        cout<<"1.  Tambah Data Kebun Binatang"<<endl;
        cout<<"2.  Tambah Data Hewan"<<endl;
        cout<<"3.  Hapus Data Kebun Binatang"<<endl;
        cout<<"4.  Hapus Data Hewan"<<endl;
        cout<<"5.  Tentukan Relasi Hewan Dan Kebun Binatang"<<endl;
        cout<<"6.  Hapus Relasi Hewan Dan Kebun Binatang"<<endl;
        cout<<"7.  Tampilkan Relasi"<<endl;
        cout<<"8.  Tampilkan Data Hewan Kebun Binatang Tertentu"<<endl;
        cout<<"9.  Tampilkan Data Kebun Binatang Hewan Tertentu"<<endl;
        cout<<"10. Tampilkan Kebun Binatang dengan Hewan paling banyak dan sedikit"<<endl;
        cout<<"Masukan Pilihan Menu : ";
        cin>>choice;
        cout<<endl<<endl;
        if(choice==1){
            system("cls");
            cout<<"Menu Tambah Kebun Binatang"<<endl;
            infotype_zoo zoo;
            cout<<"Masukan Nama Kebun Binatang : ";
            cin>>zoo.nameZoo;
            h = createElmZoo(zoo);
            insertZoo(z,h);
        }else if(choice==2){
            system("cls");
            cout<<"Menu Tambah Hewan"<<endl;
            infotype_animal animal;
            cout<<"Masukan Nama Hewan : ";
            cin>>animal.nameAnimal;
            g = createElmAnimal(animal);
            insertAnimal(a, g);
        }else if(choice==3){
            system("cls");
            cout<<"Menu Hapus Kebun Binatang"<<endl;
            infotype_zoo zoo;
            cout<<"Masukan Kebun Binatang : ";
            cin>>zoo.nameZoo;
            h = createElmZoo(zoo);
            deleteZoo(z, r, zoo.nameZoo);
            system("pause");
        }else if(choice==4){
            system("cls");
            cout<<"Menu Hapus Hewan"<<endl;
            infotype_animal animal;
            cout<<"Masukan Nama Hewan : ";
            cin>>animal.nameAnimal;
            g = createElmAnimal(animal);
            deleteAnimal(a, r, animal.nameAnimal);
            system("pause");
        }else if(choice==5){
            system("cls");
            cout<<"Menu Penentuan Data Hewan Dan Kebun Binatang"<<endl;
            infotype_zoo zoo;
            cout<<"Masukan Nama Kebun Binatang : ";
            cin>>zoo.nameZoo;
            infotype_animal animal;
            cout<<"Masukan Nama Hewan Yang Akan Ditentukan : ";
            cin>>animal.nameAnimal;
            addRelation(a,z,r,animal.nameAnimal,zoo.nameZoo);
            system("pause");
        }else if(choice==6){
            system("cls");
            cout<<"Menu Hapus Relasi"<<endl<<endl;
            infotype_animal animal;
            cout<<"Masukan Nama Hewan Yang Akan Dihapus : ";
            cin>>animal.nameAnimal;
            infotype_zoo zoo;
            cout<<"Masukan Nama Kebun Binatang Yang Akan Dihapus : ";
            cin>>zoo.nameZoo;
            deleteRelationZoo(a,z,r,animal.nameAnimal,zoo.nameZoo);
        }else if(choice==7){
            system("cls");
            view(z,r);
            system("pause");
        }else if(choice==8){
            system("cls");
            cout<<"**Menu Menampilkan Kebun Binatang Tertentu**"<<endl<<endl;
            infotype_zoo zoo;
            cout<<"Masukan Nama Kebun Binatang : ";
            cin>>zoo.nameZoo;
            cout<<endl<<endl;
            viewAnimalZoo(z, r, zoo.nameZoo);
            system("pause");
        }else if(choice==9){
            system("cls");
            cout<<"**Menu Menampilkan Hewan Tertentu**"<<endl<<endl;
            infotype_animal animal;
            cout<<"Masukan Nama Hewan : ";
            cin>>animal.nameAnimal;
            cout<<endl<<endl;
            viewZooAnimal(a, r, animal.nameAnimal);
            system("pause");
        }else if(choice==10){
            system("cls");
            view(z,r);
            sortingbanyak(z,r);
            sortingsedikit(z,r);
            //minimal(z,r);
            system("pause");
        }
    }
}
