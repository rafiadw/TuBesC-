#include "rafi.h"

adr_animal createElmAnimal(infotype_animal animal){
    adr_animal p = new elm_animal;
    p->next_animal = NULL;
    p->prev_animal = NULL;
    p->info_animal = animal;
    return p;
}
adr_zoo createElmZoo(infotype_zoo zoo){
    adr_zoo p = new elm_zoo;
    p->next_zoo = NULL;
    p->info_zoo = zoo;
    return p;
}
adr_relation createElmRelation(){
    adr_relation p = new elm_relation;
    p->next_animal = NULL;
    p->next_zoo = NULL;
    p->next_relation = NULL;
    return p;
}
void createListAnimal(list_animal &a){
    a.first_animal = NULL;
    a.last_animal = NULL;
}
void createListZoo(list_zoo &z){
    z.first_zoo = NULL;
}
void createListRelation(list_relation &r){
    r.first_relation = NULL;
}
void insertAnimal(list_animal &a, adr_animal p){
    if((a.first_animal!=NULL) && (a.last_animal!=NULL)){
        p->prev_animal = a.first_animal;
        a.last_animal->next_animal = p;
        a.last_animal = p;
    }else{
        a.first_animal = p;
        a.last_animal = p;
    }
}
void insertZoo(list_zoo &z, adr_zoo q){
    if(z.first_zoo!=NULL){
        q->next_zoo = z.first_zoo;
        z.first_zoo = q;
    }else{
        z.first_zoo = q;
    }
}

void deleteAnimal(list_animal &a,list_relation &r, string nameAnimal){
    adr_animal p = searchAnimal(a, nameAnimal);
    if(p != NULL){
        adr_relation q = r.first_relation;
        //adr_relation c;
        while(q != NULL){
            if(q->next_animal != NULL){
                q->next_animal = NULL;
                q->next_zoo = NULL;
                deleteRelation(r,q);
            }
            q = q->next_relation;
        }
        if(p == a.first_animal){
            a.first_animal = p->next_animal;
            p->next_animal = NULL;
            a.first_animal->prev_animal = NULL;
        }else{
            adr_animal b = a.first_animal;
            while(b->next_animal != p){
                b = b->next_animal;
            }
            b->next_animal = p->next_animal;
            p->next_animal = NULL;
            a.first_animal->prev_animal = NULL;
        }
    }
}

void deleteZoo(list_zoo &z, list_relation &r, string nameZoo){
    adr_zoo p = searchZoo(z, nameZoo);
    if(p!= NULL){
        adr_relation q = r.first_relation;
        while (q != NULL){
            if(q->next_zoo == p){
                cout<<q->next_zoo->info_zoo.nameZoo;
                q->next_zoo = NULL;
                q->next_animal = NULL;
                deleteRelation(r,q);
            }
            q = q->next_relation;
        }
        if(p == z.first_zoo){
            z.first_zoo = p->next_zoo;
            p->next_zoo = NULL;
        }else{
            adr_zoo b = z.first_zoo;
            while(b->next_zoo != p){
                b = b->next_zoo;
            }
            b->next_zoo = p->next_zoo;
            p->next_zoo = NULL;
        }
    }
}

adr_animal searchAnimal(list_animal a, string nameAnimal){
    adr_animal p = a.first_animal;
    while((p->info_animal.nameAnimal!=nameAnimal) && (p->next_animal!=NULL)){
        p = p->next_animal;
    }
    if(p->info_animal.nameAnimal==nameAnimal){
        return p;
    }else{
        return NULL;
    }
}
adr_zoo searchZoo(list_zoo z, string nameZoo){
    adr_zoo p = z.first_zoo;
    while((p->info_zoo.nameZoo!=nameZoo) && (p->next_zoo!=NULL)){
        p = p->next_zoo;
    }
    if(p->info_zoo.nameZoo==nameZoo){
        return p;
    }else{
        return NULL;
    }
}

void addRelation(list_animal a, list_zoo z, list_relation &r, string nameAnimal, string nameZoo){
    adr_animal p = searchAnimal(a, nameAnimal);
    adr_zoo q = searchZoo(z, nameZoo);
    if(p!=NULL && q!=NULL){
        adr_relation rr = createElmRelation();
        rr->next_animal = p;
        rr->next_zoo = q;
        if(r.first_relation==NULL){
            r.first_relation = rr;
        }else{
            rr->next_relation = r.first_relation;
            r.first_relation = rr;
        }
	}
	else
        cout<<"data tidak ada"<<endl;
}

void deleteRelation(list_relation &r, adr_relation p){
    if(p == r.first_relation){
        r.first_relation = p->next_relation;
    }else{
        adr_relation q = r.first_relation;
        while(q->next_relation != p){
            q = q->next_relation;
        }
        q->next_relation = p->next_relation;
    }
}

void deleteRelationZoo(list_animal a, list_zoo z, list_relation &r, string nameAnimal, string nameZoo){
    adr_relation p = r.first_relation;
    if(p != NULL){
        while((p->next_zoo->info_zoo.nameZoo != nameZoo || p->next_animal->info_animal.nameAnimal != nameAnimal) && (p->next_relation != NULL)){
            p = p->next_relation;
        }
        if(p->next_zoo->info_zoo.nameZoo == nameZoo && p->next_animal->info_animal.nameAnimal == nameAnimal){
            p->next_zoo = NULL;
            p->next_animal = NULL;
            deleteRelation(r,p);
        }
    }
}

void viewAnimal(list_animal a){
    cout<<"Data Hewan : ";
    if(a.first_animal==NULL){
        cout<<"Tidak Ditemukan"<<endl;
    }else{
        adr_animal r = a.first_animal;
        while(r!=NULL){
            cout<<r->info_animal.nameAnimal<<", ";
            r = r->next_animal;
        }
        cout<<endl;
    }
}

void viewZoo(list_zoo z){
    cout<<"Data Kebun Binatang : ";
    if(z.first_zoo==NULL){
        cout<<"Tidak Ditemukan"<<endl;
    }else{
        adr_zoo r = z.first_zoo;
        while(r!=NULL){
            cout<<" ,"<<r->info_zoo.nameZoo;
            r = r->next_zoo;
        }
        cout<<endl;
    }
}

void viewRelation(list_relation r){
    adr_relation p = r.first_relation;
    while(p!=NULL){
        cout<<"animal : "<<p->next_animal->info_animal.nameAnimal<<endl;
        cout<<"zoo : "<<p->next_zoo->info_zoo.nameZoo<<endl;
        p = p->next_relation;
    }
}

void view(list_zoo z, list_relation r){
    adr_zoo q = z.first_zoo;
    while(q != NULL){
        cout<<"Kebun Binatang : "<<q->info_zoo.nameZoo<<endl;
        cout<<"Nama Hewan : ";
        adr_relation rr = r.first_relation;
        while(rr != NULL){
            if(rr->next_zoo == q){
            cout<<rr->next_animal->info_animal.nameAnimal<<",";
            }
            rr = rr->next_relation;
        }
        q = q->next_zoo;
        cout<<endl<<endl;
    }
}

void viewAnimalZoo(list_zoo &z, list_relation r, string nameZoo){
    adr_zoo q = searchZoo(z, nameZoo);
    if(q != NULL){
        cout<<"Nama Kebun Binatang : "<<q->info_zoo.nameZoo<<endl;
        adr_relation rr = r.first_relation;
        cout<<"Hewan : ";
        while(rr != NULL){
            if(rr->next_zoo == q){
                cout<<rr->next_animal->info_animal.nameAnimal<<", ";
            }
            rr = rr->next_relation;
        }
        q = q->next_zoo;
    }
}

void viewZooAnimal(list_animal &a, list_relation r, string nameAnimal){
    adr_animal p = searchAnimal(a, nameAnimal);
    if(p != NULL){
        cout<<"Nama Hewan : "<<p->info_animal.nameAnimal<<endl;
        adr_relation rr = r.first_relation;
        cout<<"Kebun Binatang : ";
        while(rr != NULL){
            if(rr->next_animal == p){
                cout<<rr->next_zoo->info_zoo.nameZoo<<", ";
            }
            rr = rr->next_relation;
        }
        p = p->next_animal;
    }
}

