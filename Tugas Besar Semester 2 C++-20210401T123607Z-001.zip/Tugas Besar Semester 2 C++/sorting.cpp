#include "rafi.h"

void sortingbanyak(list_zoo z, list_relation r){
    adr_zoo q = z.first_zoo;
    adr_zoo zMak = z.first_zoo;
    //adr_zoo zMin = z.first_zoo;
    int maxAnimal = 0;
    //int minAnimal = 9999;
    if(q != NULL){
        while(q != NULL){
            adr_relation rr = r.first_relation;
            int jumlah = 0;
            while(rr != NULL){
                if(rr->next_zoo == q){
                    jumlah++;
                }
                rr = rr->next_relation;
            }
            if(jumlah > maxAnimal){
                maxAnimal = jumlah;
                zMak = q;
            }
            //if(jumlah < minAnimal){
              //  minAnimal = jumlah;
                //zMin= q;
            //}
            q = q->next_zoo;
        }
        cout<<"Kebun Binatang Hewan Terbanyak : ";
        if(zMak == NULL){
            cout<<zMak->info_zoo.nameZoo;
        }else{
            while(zMak != NULL){
                cout<<zMak->info_zoo.nameZoo<<", ";
                zMak = zMak->next_zoo;
            }
        }
        cout<<endl;
        //cout<<"Kebun Binatang Hewan Terbanyak : "<<zMak->info_zoo.nameZoo<<endl;
        cout<<"Jumlah Hewan : "<<maxAnimal<<endl<<endl;
        //cout<<"Kebun Binatang Sedikit : "<<zMin->info_zoo.nameZoo<<endl;
        //cout<<"Jumlah Hewan : "<<minAnimal<<endl<<endl;
    }
}

void sortingsedikit(list_zoo z, list_relation r){
    adr_zoo q = z.first_zoo;
    //adr_zoo zMak = z.first_zoo;
    adr_zoo zMin = z.first_zoo;
    //int maxAnimal = 0;
    int minAnimal = 9999;
    if(q != NULL){
        while(q != NULL){
            adr_relation rr = r.first_relation;
            int jumlah = 0;
            while(rr != NULL){
                if(rr->next_zoo == q){
                    jumlah++;
                }
                rr = rr->next_relation;
            }
            //if(jumlah < maxAnimal){
                //maxAnimal = jumlah;
                //zMak = q;
            //}
            if(jumlah < minAnimal){
                minAnimal = jumlah;
                zMin= q;
            }
            q = q->next_zoo;
        }
        //cout<<"Kebun Binatang Hewan Terbanyak : "<<zMak->info_zoo.nameZoo<<endl;
        //cout<<"Jumlah Hewan : "<<maxAnimal<<endl<<endl;
        cout<<"Kebun Binatang Sedikit : "<<zMin->info_zoo.nameZoo<<endl;
        cout<<"Jumlah Hewan : "<<minAnimal<<endl<<endl;
    }
}


/*
void minimal(list_zoo z, list_relation r){
    adr_zoo q = z.first_zoo;
    int jumlah;
    while(q != NULL){
            jumlah++;
            adr_zoo g = g->next_zoo;
        }
        int indeks = 0;
        int hasil[indeks];
        string nama[indeks];
        adr_zoo qq = z.first_zoo;
        while(qq != NULL){
            jumlah = 0;
            adr_relation rr = r.first_relation;
            while(rr != NULL){
                if(rr->next_zoo == qq->next_zoo){
                    jumlah++;
                }
                rr = rr->next_relation;
            }
            nama[indeks] = jumlah;
            hasil[indeks] = jumlah;
            indeks++;
            qq = qq->next_zoo;
        }
        for(int i = 0; i<jumlah; i++){
            for(int j = i+1; j<jumlah; j++){
                if(hasil[i]<hasil[j]){
                    int angka = hasil[i];
                    hasil[i] = hasil[j];
                    hasil[j] = angka;

                    string n = nama[i];
                    nama[i] = nama[j];
                    nama[j] = n;
                }
            }
        }
        cout<<nama[0];
        cout<<hasil[0];
    }






   /*while(q != NULL){
            adr_relation rr = r.first_relation;
            while(rr != NULL){
                if(rr->next_zoo == q){
                    jAnimal2 = jAnimal2 + 1;
                }
                rr = rr->next_relation;
            }
            if(minAnimal > jAnimal2){
                minAnimal = jAnimal2;
                zMin = q;
            }
            q = q->next_zoo;
        }*/


/*
void viewsorting(list_orang s, list_film c, list_relation r, int w, int i){
adr_orang p = s.first_orang;
int lmax = 0;
int pmax = 0;
adr_orang lmak = s.first_orang;
adr_orang pmak = s.first_orang;
if((p!=NULL)){
        while((p!=NULL)){
        adr_relation q;
        q = r.first_relation;
        int lhasil = 0;
        int phasil = 0;
            if(p->info_orang.kelamin==1){
                    while((q!=NULL)&&(p->info_orang.kelamin==1)){
                        if(q->next_orang==p){
                            lhasil = lhasil+1;
                        }
                        q = q->next_relation;
                    }
                    if(lmax<lhasil){
                        lmax = lhasil;
                        lmak = p;
                    }
*/
