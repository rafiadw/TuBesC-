#ifndef RAFI_H_INCLUDED
#define RAFI_H_INCLUDED
#include<string>
#include<iostream>

using namespace std;

struct infotype_animal{
    string nameAnimal;
};

struct infotype_zoo{
    string nameZoo;
    int jumlahHewan;
};

typedef struct elm_animal *adr_animal;
typedef struct elm_zoo *adr_zoo;
typedef struct elm_relation *adr_relation;

struct list_animal{
    adr_animal first_animal;
    adr_animal last_animal;
};

struct list_zoo{
    adr_zoo first_zoo;
};

struct list_relation{
    adr_relation first_relation;
};

struct elm_animal{
    adr_animal next_animal;
    adr_animal prev_animal;
    infotype_animal info_animal;
};

struct elm_zoo{
    adr_zoo next_zoo;
    infotype_zoo info_zoo;
};

struct elm_relation{
    adr_animal next_animal;
    adr_zoo next_zoo;
    adr_relation next_relation;
};

adr_animal createElmAnimal(infotype_animal animal);
adr_zoo createElmZoo(infotype_zoo zoo);
adr_relation createElmRelation();
void createListAnimal(list_animal &a);
void createListZoo(list_zoo &z);
void createListRelation(list_relation &r);

adr_animal searchAnimal(list_animal a, string nameAnimal);
adr_zoo searchZoo(list_zoo z, string nameZoo);
void insertAnimal(list_animal &a, adr_animal p);
void insertZoo(list_zoo &z, adr_zoo q);

void deleteAnimal(list_animal &a,list_relation &r, string nameAnimal);
void deleteZoo(list_zoo &z, list_relation &r, string nameZoo);

void addRelation(list_animal a, list_zoo z, list_relation &r, string nameAnimal, string nameZoo);

void deleteRelation(list_relation &r, adr_relation p);
void deleteRelationZoo(list_animal a, list_zoo z, list_relation &r, string nameAnimal, string nameZoo);

void viewAnimal(list_animal a);
void viewZoo(list_zoo name);
void view(list_zoo z, list_relation r);
void viewRelation(list_relation r);
void viewAnimalZoo(list_zoo &z, list_relation r, string nameZoo);
void viewZooAnimal(list_animal &a, list_relation r, string nameAnimal);

void sortingbanyak(list_zoo z, list_relation r);
void sortingsedikit(list_zoo z, list_relation r);
void minimal(list_zoo z, list_relation r);


#endif // RAFI_H_INCLUDED
